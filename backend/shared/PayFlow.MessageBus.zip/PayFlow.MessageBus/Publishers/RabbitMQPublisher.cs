﻿using PayFlow.MessageBus.Configurations;
using PayFlow.MessageBus.Interfaces;
using PayFlow.MessageBus.Serialization;
using RabbitMQ.Client;

namespace PayFlow.MessageBus.Publishers;

public class RabbitMQPublisher
    : IMessageBus
{
    private readonly RabbitMQSettings
        _settings;

    public RabbitMQPublisher(
        RabbitMQSettings settings)
    {
        _settings = settings;
    }

    public async Task PublishAsync<T>(
        string routingKey,
        T message)
    {
        var factory =
            new ConnectionFactory
            {
                HostName =
                    _settings.HostName,

                Port =
                    _settings.Port,

                UserName =
                    _settings.UserName,

                Password =
                    _settings.Password
            };

        using var connection =
            await factory.CreateConnectionAsync();

        using var channel =
            await connection.CreateChannelAsync();

        await channel.ExchangeDeclareAsync(

            exchange:
                _settings.Exchange,

            type:
                ExchangeType.Topic,

            durable: true,

            autoDelete: false

        );

        var body =
            JsonSerializerHelper
                .Serialize(message);

        await channel.BasicPublishAsync(

            exchange:
                _settings.Exchange,

            routingKey:
                routingKey,

            mandatory: false,

            body:
                body

        );
    }
}